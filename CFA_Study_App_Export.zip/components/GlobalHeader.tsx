import { C, R } from '@/constants/theme';
import { useTimer } from '@/lib/TimerContext';
import { generateSyncUrl, supabase } from '@/lib/supabaseClient';
import { Check, RefreshCcw, Zap } from 'lucide-react-native';
import React from 'react';
import { Alert, Pressable, Share, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

/**
 * GlobalCommandHeader
 * Anchored at the top of the app in TabLayout.
 * Provides consistent visibility for Auth and Sync controls.
 */
export function GlobalCommandHeader() {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { userId, userEmail, signInWithGoogle, forceMerge } = useTimer();
  const isMobile = width < 768;

  const handleAuthPress = () => {
    if (userEmail) {
      forceMerge();
    } else {
      signInWithGoogle();
    }
  };

  /**
   * Magic Link Share (v1.5.2 correction)
   * Uses centralized generator to build platform-correct sync links.
   */
  const onSyncPress = async () => {
    Alert.alert(
      'Sync Workspace',
      'This MAGIC LINK pairs your other device to this study history.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Generate Link',
          onPress: async () => {
            try {
              const { data: { session } } = await supabase.auth.getSession();
              const rt = session?.refresh_token || null;
              const syncURL = generateSyncUrl(userId, rt);

              await Share.share({
                message: syncURL,
                url: syncURL,
              });
            } catch (a: any) {
              Alert.alert('Sync Error', 'Cloud sync is currently unavailable.');
            }
          }
        }
      ]
    );
  };

  return (
    <View style={[s.globalHeader, { paddingTop: Math.max(insets.top, 12) }]}>
      <View style={[s.content, { maxWidth: 1200, alignSelf: 'center', width: '100%', paddingHorizontal: isMobile ? 12 : 24 }]}>
        <View style={s.row}>
          {/* Branded Title */}
          <View style={s.brand}>
            <View style={s.brandMark}>
              <Text style={s.brandMarkTxt}>R</Text>
            </View>
            <Text style={s.brandTxt}>R1</Text>
          </View>

          {/* Controls */}
          <View style={s.controls}>
            {/* 1. Magic Link */}
            <Pressable
              onPress={onSyncPress}
              style={({ pressed }) => [s.btn, s.btnMagic, pressed && { opacity: 0.7 }]}
            >
              <RefreshCcw size={14} color={C.accentBlue} />
              <Text style={s.btnTxt}>MAGIC LINK</Text>
            </Pressable>

            {/* 2. Google Login / Badge */}
            <Pressable
              onPress={handleAuthPress}
              style={({ pressed }) => [
                s.btn,
                userEmail ? s.btnProfile : s.btnGoogle,
                pressed && { opacity: 0.7 }
              ]}
            >
              {userEmail ? (
                <>
                  <Check size={14} color={C.accentBlue} />
                  <Text style={[s.btnTxt, s.profileTxt]} numberOfLines={1}>{userEmail}</Text>
                </>
              ) : (
                <>
                  <RefreshCcw size={14} color="#fff" />
                  <Text style={[s.btnTxt, { color: '#fff' }]}>SYNC GOOGLE</Text>
                </>
              )}
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  globalHeader: {
    backgroundColor: C.primaryBG,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
    paddingVertical: 12,
    zIndex: 100,
  },
  content: {
    flexDirection: 'column',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  brand: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  brandTxt: {
    color: C.white,
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: R.xs,
    borderWidth: 1,
  },
  btnMagic: {
    backgroundColor: 'rgba(250, 191, 65, 0.05)',
    borderColor: 'rgba(250, 191, 65, 0.15)',
  },
  btnGoogle: {
    backgroundColor: '#4285F4',
    borderColor: '#4285F4',
  },
  btnProfile: {
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderColor: 'rgba(255,255,255,0.08)',
    maxWidth: 160,
  },
  btnTxt: {
    fontSize: 10,
    fontWeight: '800',
    color: C.accentBlue,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  brandMark: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: 'rgba(250, 191, 65, 0.12)',
    borderWidth: 1,
    borderColor: 'rgba(250, 191, 65, 0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandMarkTxt: {
    color: C.accentBlue,
    fontSize: 14,
    fontWeight: '900',
  },
  profileTxt: {
    color: C.white,
    textTransform: 'none',
  }
});
